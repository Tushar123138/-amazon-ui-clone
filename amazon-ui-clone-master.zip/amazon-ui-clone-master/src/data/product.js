const products = [
  {
    id: 1,
    title: "Apple iPhone 14",
    price: 69999,
    rating: 4.5,
    image: "https://via.placeholder.com/200",
    description: "Latest iPhone with A15 chip"
  },
  {
    id: 2,
    title: "Samsung Galaxy S23",
    price: 64999,
    rating: 4.3,
    image: "https://via.placeholder.com/200",
    description: "Flagship Android smartphone"
  }
];

export default products;
